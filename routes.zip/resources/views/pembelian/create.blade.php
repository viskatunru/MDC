@extends('master')

@section('content')
<h3>Tambah Pembelian Baru</h3>
<div class="tab-content">
	<div class="tab-pane active" id="horizontal-form">
		<form class="form-horizontal" method="post">
			{{csrf_field()}}
			<div class="form-group">
				<label for="focusedinput" class="col-sm-2 control-label">Tanggal</label>
				<div class="col-sm-8">
					<input type="date" class="form-control1" id="focusedinput" placeholder="" name="tanggal">
				</div>
			</div>
			<div class="form-group">
				<label for="selector1" class="col-sm-2 control-label">Supplier</label>
				<div class="col-sm-8">
					<select name="id_supplier" id="selector1" class="form-control1">
						<option selected disabled>...</option>
						@foreach($suppliers as $supplier)
							<option value="{{$supplier->id}}">{{$supplier->nama}}</option>
						@endforeach
					</select>
				</div>
				<div class="col-sm-2">
				    <a class="btn btn-primary" href="/supplier/add">Tambah</a>
				</div>
			</div>
			<div class="form-group">
				<label for="focusedinput" class="col-sm-2 control-label">Nama Barang</label>
				<div class="col-sm-8">
					<input type="text" class="form-control1" id="focusedinput" placeholder="" name="nama_barang">
				</div>
			</div>
			<div class="form-group">
				<label for="focusedinput" class="col-sm-2 control-label">Jumlah Barang</label>
				<div class="col-sm-8">
					<input type="number" class="form-control1" id="focusedinput" placeholder="" name="stok">
				</div>
			</div>
			<div class="col-sm-8 col-sm-offset-2">
				<button class="btn-success btn">Submit</button>
				<button class="btn-inverse btn">Reset</button>
			</div>
		</form>
	</div>
</div>
@endsection