@extends('master')
@section('content')
<h3>Pembelian dari : {{$supplier->nama}}</h3>
<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
	<div class="panel-body no-padding">
		<table class="table table-striped">
			<thead>
				<tr class="warning">
					<th>Tanggal</th>
					<th>Supplier</th>
					<th>Show Semua Barang</th>
				</tr>
			</thead>
			<tbody>
				@foreach($pembelians as $pembelian)
				<tr>
					<td>{{$pembelian->tanggal}}</td>
					<td>{{$pembelian->supplier->nama}}</td>
					<td><a href="/pembelian/show/{{$pembelian->id}}" class="btn btn-primary">Show</a></td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection