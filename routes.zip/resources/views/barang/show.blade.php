@extends('master')

@section('content')

{{$barang->id}}
{{$barang->nama}}
{{$barang->stok}}
{{$barang->category->nama}}

@foreach($expires as $expire)
	{{$expire->id}}
	{{$expire->tanggal}}
	{{$expire->jumlah}}
	{{$expire->penyimpanan->nama}}
@endforeach

<form id="formPemakaian">
	<select id="tipe">
		<option value="1">Month</option>
		<option value="2">Year</option>
	</select>

	<select id="tahun">
		<option value="2017">2017</option>
	</select>

	<select id="bulan">
		<option value="1">Januari</option>
		<option value="2">Februari</option>		
	</select>
	<input type="submit" name="" value="Submit">
</form>

<div id="divPemakaian">

</div>

<script type="text/javascript">
	$('#tipe').change(function(){
		var tipe = $('#tipe').val();
		if (tipe == 1)
		{
			$('#bulan').removeAttr("hidden");
		}
		else
		{
			$('#bulan').attr("hidden", true);
			$('#tahun').removeAttr("hidden");
		}
	});

	$('#formPemakaian').submit(function(e){
		var url = "";
		var tipe = $('#tipe').val();
		if (tipe == 1)
			url = '/ajax/barang/showMonthly';
		else
			url = '/ajax/barang/showYearly';
		e.preventDefault();
	    $.ajax({
	        type: "GET",
	        url: url,
	        data: { 
	        	tahun: $('#tahun').val(),
	        	bulan: $('#bulan').val(),
	        	id_barang: {{$barang->id}}
	        }, 
	        success: function( data ) {
	        	$('#divPemakaian').html(data);
	        }
	    });
    });
</script>

@endsection