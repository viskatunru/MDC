@extends('master')

@section('content')
<h3>Home</h3>
<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
	<div class="panel-body no-padding">
		<table class="table table-striped">
			<thead>
				<tr class="warning">
					<th>ID</th>
					<th>Kode Barang</th>
					<th>Nama Barang</th>
					@foreach($dokters as $dokter)
					<th>{{$dokter->nama}}</th>
					@endforeach
					<th>Stok Sekarang</th>
				</tr>
			</thead>
			<tbody>
				@foreach($barangs as $barang)
				<tr>
					<td>{{$barang->id}}</td>
					<td>{{$barang->category->nama}}</td>
					<td><a href="/barang/show/{{$barang->id}}">{{$barang->nama}}</a></td>
					@foreach($dokters as $dokter)
					<?php
						$pemakaians = $barang->pemakaians->where('dokter_id', '=', $dokter->id);
						$jumlah = 0;
						foreach ($pemakaians as $pemakaian)
						{
							$jumlah += $pemakaian->jumlah;
						}
					?>
					@if($jumlah > 0)
					<td>{{$jumlah}}</td>
					@else
					<td>-</td>
					@endif
					@endforeach
					<td>{{$barang->stok}}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>

<h3>Print Laporan</h3>
<form method="get" action="/pdf/stok">
	<input type="month" name="bulan">
	<button type="submit">Submit</button>
</form>

<h3>Yang mau expire :</h3>
<form method="get" id="formHariExpire">
	<label>Expire dalam berapa hari?</label>
	<input type="number" name="hari" id="inputHari">
	<button type="submit">Submit</button>
</form>
<br>

<div id="barangByExpireDiv">

</div>
<script type="text/javascript">
	$('#formHariExpire').submit(function(e){
		e.preventDefault();
	    $.ajax({
	        type: "GET",
	        url: "/ajax/barangByExpiryDate",
	        data: { 
	        	tanggal: $('#inputHari').val()
	        }, 
	        success: function( msg ) {
	        	$('#barangByExpireDiv').html(msg);
	        }
	    });
    });
</script>
@endsection