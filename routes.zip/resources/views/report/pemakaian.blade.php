@extends('master')

@section('content')
<h3>Home</h3>
<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
	<div class="panel-body no-padding">
		<table class="table table-striped">
			<thead>
				<tr class="warning">
					<th>ID</th>
					<th>Kode Barang</th>
					<th>Nama Barang</th>
					<th>Jumlah Barang</th>
					<?php $jumlah = array(); ?>
					@foreach($dokters as $dokter)
					<th>{{$dokter->nama}}</th>
					<?php $jumlah[$dokter->id] = 0; ?>
					@endforeach
					<th>Total Pemakaian</th>
					<th>Stok Akhir</th>
				</tr>
			</thead>
			<tbody>
				@foreach($barangs as $barang)
				<tr>
					<td>{{$barang->id}}</td>
					<td>{{$barang->category->nama}}</td>
					<td><a href="/barang/show/{{$barang->id}}">{{$barang->nama}}</a></td>
					<td>{{$barang->stok}}</td>

					<?php $total = 0;?>
					@foreach($pemakaiansBulanIni->where("barang_id", '=', $barang->id) as $pemakaian)
						@foreach($dokters as $dokter)
							@if($dokter->id == $pemakaian->dokter_id)
								<?php $jumlah[$dokter->id] += $pemakaian->jumlah; ?>
							@endif
						@endforeach
					@endforeach

					@foreach($dokters as $dokter)
					<td>
						<?php 
						if($jumlah[$dokter->id] > 0) 
							echo $jumlah[$dokter->id]; 
						else
							echo "-";
						$total += $jumlah[$dokter->id];
						$jumlah[$dokter->id] = 0; 
						?>
					</td>
					@endforeach
					<td>{{$total}}</td>
					<td>{{$barang->stok - $total}}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection