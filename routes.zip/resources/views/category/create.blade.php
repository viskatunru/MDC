@extends('master')

@section('content')
<h3>Tambah Kategori Baru</h3>
<div class="tab-content">
	<div class="tab-pane active" id="horizontal-form">
		<form class="form-horizontal" method="post" action="#">
		    {{csrf_field()}}
			<div class="form-group">
				<label for="focusedinput" class="col-sm-2 control-label">Nama Kategori</label>
				<div class="col-sm-8">
					<input type="text" class="form-control1" id="focusedinput" placeholder="" name="nama_kategori">
				</div>
			</div>
			<div class="col-sm-8 col-sm-offset-2">
				<button class="btn-primary btn" type="submit">Submit</button>
				<button class="btn-inverse btn">Reset</button>
			</div>
		</form>
	</div>
</div>
@endsection