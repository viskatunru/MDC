<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Expire, App\Barang, Carbon\Carbon;

class AjaxController extends Controller
{
    //

    public function barangByExpiryDate()
    {	
    	$tanggal = Input::get('tanggal', 0);

    	$date = (int)date("d");
    	$month = (int)date('m');
    	$year = (int)date("Y");    	

    	$uppBound = $date + $tanggal + 1;

    	$expires = Expire::where('tanggal', '>=', "$year-$month-$date 00:00:00")
    			->where('tanggal', '<=', "$year-$month-$uppBound 00:00:00")
    			->get();

    	return view('template.barangByExpire', compact('expires'));
    }
}
