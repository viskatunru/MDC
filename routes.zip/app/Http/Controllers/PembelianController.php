<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pembelian, App\Supplier, App\Barang;
class PembelianController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $pembelians = Pembelian::all();
        return view('pembelian.index', compact('pembelians'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $suppliers = Supplier::all();
        return view('pembelian.create', compact('suppliers'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $pembelian = new Pembelian;
        $pembelian->tanggal = $request->tanggal;
        $pembelian->supplier_id = $request->id_supplier;
        $pembelian->save();

        $barang = Barang::find($request->id_barang);        
        $barang->stok += $request->jumlah_barang;
        $barang->save();

        $expire = Expire::where('barang_id', '=', $barang->id)
                ->where('tanggal', '=', $request->tanggal_expire)->first();
        if ($expire == null)
        {
            $expire = new Expire;
            $expire->tanggal = $request->tanggal_expire;
            $expire->jumlah = $request->jumlah_barang;
            $expire->penyimpanan_id = $request->id_penyimpanan;
            $expire->barang_id = $barang->id;
        }
        else
        {
            $expire->jumlah += $request->jumlah_barang;
        }
        $expire->save();
        
        return redirect()->action('PembelianController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $pembelian = Pembelian::find($id);
        $barangs = $pembelian->barangs;
        return view('pembelian.show', compact('barangs'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
