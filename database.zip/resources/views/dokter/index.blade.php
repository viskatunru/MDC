@extends('master')

@section('content')
<h3>DAFTAR DOKTER</h3>

<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
	<div class="panel-body no-padding">
		<table class="table table-striped">
			<thead>
				<tr class="warning">
					<th>ID</th>
					<th>Nama Dokter</th>
					<th>Edit</th>
					<th>Tampilkan Semua Pemakaian</th>
				</tr>
			</thead>
			
			<tbody>
				@foreach($dokters as $dokter)
					<tr>
						<td>{{$dokter->id}}</td>
						<td>{{$dokter->nama}}</a></td>
						<td><a href="/dokter/edit/{{$dokter->id}}" class="btn btn-primary">Edit</a></td>
						<td><a href="/dokter/show/{{$dokter->id}}" class="btn btn-primary">Tampilkan</a></td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection