@extends('master')

@section('content')
<h3>DAFTAR PEMAKAIAN</h3>

<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
	<div class="panel-body no-padding">
		<table class="table table-striped">
			<thead>
				<tr class="warning">
					<th>Tanggal</th>
					<th>Nama Dokter</th>
					<th>Nama Barang</th>
					<th>Jumlah Pemakaian</th>
				</tr>
			</thead>
			
			<tbody>
				@foreach($pemakaians as $pemakaian)
					<tr>
						<td>{{$pemakaian->tanggal}}</td>
						<td><a href="/dokter/show/{{$pemakaian->dokter->id}}">{{$pemakaian->dokter->nama}}</td>
						<td><a href="/barang/show/{{$pemakaian->barang->id}}">{{$pemakaian->barang->nama}}</a></td>
						<td>{{$pemakaian->jumlah}}</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection