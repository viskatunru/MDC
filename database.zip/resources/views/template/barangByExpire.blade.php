<table class="table table-striped">
	<thead>
		<tr>
			<th>Nama Barang</th>
			<th>Stok Expire</th>
			<th>Lokasi</th>
		</tr>
	</thead>
	<tbody>
		@foreach($expires as $expire)
		<tr>
			<td>{{$expire->barang->nama}}</td>
			<td>{{$expire->jumlah}}</td>
			<td>{{$expire->penyimpanan->nama}}</td>
		</tr>
		@endforeach
	</tbody>
</table>