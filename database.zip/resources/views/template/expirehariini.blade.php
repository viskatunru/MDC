<!-- Isi -->
<div class="scrollbar" id="style-2">
	@if(count($expires) > 0)
		@foreach($expires as $expire)
		<div class="activity-row">
			<div class="col-xs-12 activity-desc">
			<h5><a href="/barang/show/{{$expire->barang->id}}">{{$expire->barang->nama}}</a></h5>
				<p>Stok: {{$expire->jumlah}}</p>
			</div>
			<div class="clearfix"></div>
		</div>
		@endforeach
	@else
		Tidak ada barang yang expire hari ini
	@endif
</div>