<tr>
	<th>Kode Barang</th>
	<th>{{$barang->nama}}</th>
	<th>{{$barang->stok}}</th>
	<th>Kategori</th>
	<th>{{$expire}}</th>
	<th><a href="#" class="btn">Delete</a></th>
</tr>