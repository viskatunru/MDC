@extends('master')

@section('content')
<h3>Barang</h3>
<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
	<div class="panel-body no-padding">
		<table class="table table-striped">
			<thead>
				<tr class="warning">
					<th>ID</th>
					<th>Nama Barang</th>
					<th>Kategori Barang</th>
					<th>Jumlah Barang</th>
					<th>Edit Barang</th>
				</tr>
			</thead>
			<tbody>
				@foreach($barangs as $barang)
				<tr>
					<td>{{$barang->id}}</td>
					<td><a href="/barang/show/{{$barang->id}}">{{$barang->nama}}</a></td>
					<td>{{$barang->category->nama}}</td>
					<td>{{$barang->stok}}</td>
					<td><a href="/barang/edit/{{$barang->id}}"><button>Edit</button></a></td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>
@endsection